public class Widgets {
    private Widget widget;

    public Widget getWidget() {
        return widget;
    }

    public void setWidget(Widget widget) {
        this.widget = widget;
    }

    @Override
    public String toString() {
        return "Widgets{" +
                "widget=" + widget +
                '}';
    }
}
